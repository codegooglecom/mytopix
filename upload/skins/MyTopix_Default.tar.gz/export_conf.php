<?php
$skin['skins_name']   = 'mytopix_default';
$skin['skins_author'] = 'James Mathias';
$skin['skins_link']   = 'http://1lotus.com/';
?><?php
$skin['skins_name']   = 'MyTopix_Default';
$skin['skins_author'] = 'James Mathias';
$skin['skins_link']   = 'http://1lotus.com/';
?><?php
$skin['skins_name']   = 'MyTopix_Default';
$skin['skins_author'] = 'James Mathias';
$skin['skins_link']   = 'http://1lotus.com/';
?><?php
$skin['skins_name']   = 'MyTopix_Default';
$skin['skins_author'] = 'James Mathias';
$skin['skins_link']   = 'http://1lotus.com/';
?>